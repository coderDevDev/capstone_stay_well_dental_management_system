class User {
  constructor(id, name) {
    (this.id = id), (this.name = name);
  }
}

export default User;
