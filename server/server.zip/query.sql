


SET SQL_SAFE_UPDATES = 0;
delete FROM heroku_b70aa7f20cab30e.inventory;


SET SQL_SAFE_UPDATES = 0;
delete FROM heroku_b70aa7f20cab30e.layaway;


SET SQL_SAFE_UPDATES = 0;
delete FROM heroku_b70aa7f20cab30e.notifications;


SET SQL_SAFE_UPDATES = 0;
delete FROM heroku_b70aa7f20cab30e.payments;




