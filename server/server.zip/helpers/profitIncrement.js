export const addProfit = ({
  isApproved,
  approverUserId,
  dateApprove,
  previousProfit,
  totalAmount
}) => {};
